export interface ITask {
  description: string;
  done: boolean;
}
